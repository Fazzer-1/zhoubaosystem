package com.zj.domain;

public class Shijian {
	private String kaishiTime;
	private String jieshuTime;
	public String getKaishiTime() {
		return kaishiTime;
	}
	public void setKaishiTime(String kaishiTime) {
		this.kaishiTime = kaishiTime;
	}
	public String getJieshuTime() {
		return jieshuTime;
	}
	public void setJieshuTime(String jieshuTime) {
		this.jieshuTime = jieshuTime;
	}
}
