package com.zj.domain;
import java.sql.Timestamp;

public class Log {
	private Integer logId;     		 //Id
	private Timestamp  time; 		 //写日志的时间
	private String shangwuPname; 	 //上午项目名称
	private String shangwuPlan;		 //上午项目计划任务
	private String shangwuStatus;	//上午计划状态
	private String xiawuPname;		 //下午项目名称
	private String xiawuPlan;   //下午项目计划任务
	private String xiawuStatus;  //下午计划状态
	private String writerUserCode;   //作者账号--用户
	private String writerUserName;  //作者姓名--用户
	private String writerAdminCode;   //作者账号--管理员
	private String writerAdminName;  //作者姓名--管理员
	public Integer getLogId() {
		return logId;
	}
	public void setLogId(Integer logId) {
		this.logId = logId;
	}
	public Timestamp getTime() {
		return time;
	}
	public void setTime(Timestamp time) {
		this.time = time;
	}
	public String getShangwuPname() {
		return shangwuPname;
	}
	public void setShangwuPname(String shangwuPname) {
		this.shangwuPname = shangwuPname;
	}
	public String getShangwuPlan() {
		return shangwuPlan;
	}
	public void setShangwuPlan(String shangwuPlan) {
		this.shangwuPlan = shangwuPlan;
	}
	public String getShangwuStatus() {
		return shangwuStatus;
	}
	public void setShangwuStatus(String shangwuStatus) {
		this.shangwuStatus = shangwuStatus;
	}
	public String getXiawuPname() {
		return xiawuPname;
	}
	public void setXiawuPname(String xiawuPname) {
		this.xiawuPname = xiawuPname;
	}
	public String getXiawuPlan() {
		return xiawuPlan;
	}
	public void setXiawuPlan(String xiawuPlan) {
		this.xiawuPlan = xiawuPlan;
	}
	public String getXiawuStatus() {
		return xiawuStatus;
	}
	public void setXiawuStatus(String xiawuStatus) {
		this.xiawuStatus = xiawuStatus;
	}
	public String getWriterUserCode() {
		return writerUserCode;
	}
	public void setWriterUserCode(String writerUserCode) {
		this.writerUserCode = writerUserCode;
	}
	public String getWriterUserName() {
		return writerUserName;
	}
	public void setWriterUserName(String writerUserName) {
		this.writerUserName = writerUserName;
	}
	public String getWriterAdminCode() {
		return writerAdminCode;
	}
	public void setWriterAdminCode(String writerAdminCode) {
		this.writerAdminCode = writerAdminCode;
	}
	public String getWriterAdminName() {
		return writerAdminName;
	}
	public void setWriterAdminName(String writerAdminName) {
		this.writerAdminName = writerAdminName;
	}
	
}
