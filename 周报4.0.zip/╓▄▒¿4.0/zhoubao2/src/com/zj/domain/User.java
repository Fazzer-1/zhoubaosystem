package com.zj.domain;



public class User {
	private Integer userId;        //用户编号
	private String userName; 	  //用户姓名
	private String userPid;   	  //用户身份证
	private String userCode;  	  //用户账号
	private String userPhone; //用户手机号
	private String userPassword;  //用户密码
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPid() {
		return userPid;
	}
	public void setUserPid(String userPid) {
		this.userPid = userPid;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	
}
