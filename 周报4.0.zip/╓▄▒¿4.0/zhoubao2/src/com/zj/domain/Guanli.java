package com.zj.domain;

public class Guanli {
	private Integer adminId;		 //ID	
	private String adminName; 		 //姓名
	private String adminPid; 		 //身份证
	private String adminCode;		 //账号
	private String adminPhoneNum;	 //手机
	private String adminPassword;	 //密码
	public Integer getAdminId() {
		return adminId;
	}
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	
	public String getAdminCode() {
		return adminCode;
	}
	public void setAdminCode(String adminCode) {
		this.adminCode = adminCode;
	}
	
	public String getAdminPid() {
		return adminPid;
	}
	public void setAdminPid(String adminPid) {
		this.adminPid = adminPid;
	}
	public String getAdminPhoneNum() {
		return adminPhoneNum;
	}
	public void setAdminPhoneNum(String adminPhoneNum) {
		this.adminPhoneNum = adminPhoneNum;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	
}
