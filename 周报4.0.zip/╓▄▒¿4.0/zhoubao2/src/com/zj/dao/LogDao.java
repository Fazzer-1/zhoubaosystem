package com.zj.dao;

import java.sql.Timestamp;
import java.util.List;
import com.zj.domain.Log;

public interface LogDao {
	
	//用户查询自己的日志第1步
	int findCount(String userCodePage);
	//用户查询自己的日志第二步
	List<Log> findByPage(int begin, int limit,String userCodePage);
	
	
	//用户根据时间查日志第一步
	int findCount(Timestamp startTime1, Timestamp endTime1,String timeUserCode);
	//用户根据时间查日志第2步
	List<Log> findByPage(int begin, int limit, Timestamp startTime1, Timestamp endTime1,String timeUserCode);
	
	//管理员查询自己日志第一步
	int adminFindSelfLogsCount(String adminCode);
	//管理员查询自己日志第2步
	List<Log> adminFindSelfLogsByPage(int begin, int limit, String adminCode);
	
	//管理员根据时间查日志第一步
	int adminFindSelfCount(Timestamp startTime1, Timestamp endTime1, String timeUserCode);
	//管理员根据时间查日志第2步
	List<Log> adminFindSelfByPage(int begin, int limit, Timestamp startTime1, Timestamp endTime1, String timeUserCode);
	
	//管理员根据时间查询所有日志
	int adminfindLogsByTimeCount(Timestamp startTime1, Timestamp endTime1);
	List<Log> adminfindLogsByTimeCountByPage(int begin, int limit, Timestamp startTime1, Timestamp endTime1);
}
