package com.zj.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.zj.dao.GuanliDao;
import com.zj.domain.Guanli;
import com.zj.domain.PageBean;
import com.zj.domain.ProJ;
import com.zj.domain.User;
import com.zj.utils.JDBCUtils;

public class GuanliDaoImpl implements GuanliDao {

	@Override
	public Guanli login(Guanli guanli) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "select * from admin_list where admin_code = ? and admin_password = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, guanli.getAdminCode());
			pstmt.setString(2, guanli.getAdminPassword());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				Guanli existGuanli = new Guanli();
				existGuanli.setAdminId(rs.getInt("admin_id"));
				existGuanli.setAdminName(rs.getString("admin_name"));
				existGuanli.setAdminCode(rs.getString("admin_code"));
				existGuanli.setAdminPhoneNum(rs.getString("admin_phone_num"));
				existGuanli.setAdminPassword(rs.getString("admin_password"));
				existGuanli.setAdminPid(rs.getString("admin_pid"));
				return existGuanli;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return null;
	}

	@Override
	public Guanli adminForgetPassword(Guanli guanliForget) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "select * from admin_list where admin_code = ? and admin_name = ? and admin_phone_num = ? and admin_pid = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, guanliForget.getAdminCode());
			pstmt.setString(2, guanliForget.getAdminName());
			pstmt.setString(3, guanliForget.getAdminPhoneNum());
			pstmt.setString(4, guanliForget.getAdminPid());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				Guanli existGuanliForget = new Guanli();
				existGuanliForget.setAdminId(rs.getInt("admin_id"));
				existGuanliForget.setAdminName(rs.getString("admin_name"));
				existGuanliForget.setAdminCode(rs.getString("admin_code"));
				existGuanliForget.setAdminPhoneNum(rs.getString("admin_phone_num"));
				existGuanliForget.setAdminPassword(rs.getString("admin_password"));
				existGuanliForget.setAdminPid(rs.getString("admin_pid"));
				return existGuanliForget;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return null;
	}

	@Override
	public Guanli adminUpdatePassword(Guanli guanliUpdatePassword) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "update admin_list set admin_password = ? where admin_code = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, guanliUpdatePassword.getAdminPassword());
			pstmt.setString(2, guanliUpdatePassword.getAdminCode());
			pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(pstmt, conn);
		}
		return null;
	}

	@Override
	public Guanli addUser(User addUser) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "insert into em_list(em_name,em_pid,em_code,em_phone_num,em_password) value(?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, addUser.getUserName());
			pstmt.setString(2, addUser.getUserPid());
			pstmt.setString(3, addUser.getUserCode());
			pstmt.setString(4, addUser.getUserPhone());
			pstmt.setString(5, addUser.getUserPassword());
			pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(pstmt, conn);
		}
		return null;
	}

	@Override
	public Guanli deleteUser(Integer emId) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "delete  from em_list where em_id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, emId);;
			pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(pstmt, conn);
		}
		return null;
	}

	@Override
	public ProJ addProName(ProJ proJ) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "insert into project_list(pro_name) value(?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, proJ.getProName());
			pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(pstmt, conn);
		}
		return null;
	}

	@Override
	public int findProNamesCount() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Long count = 0l; 
		try {
			//获取数据库连接
			conn = JDBCUtils.getConnection();
			//编写SQL语句:count是别名
			String sql = "select count(*) as count from project_list";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			//执行
			rs = pstmt.executeQuery();
			//判断
			if(rs.next()) {
				count = rs.getLong("count"); //count是别名&count是Long类型
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return count.intValue();  //将Long类型转换为Int类型
	}

	@Override
	public List<ProJ> findProNamesByPage(int begin, int limit) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<ProJ> pageList = null;
		try {
			conn = JDBCUtils.getConnection();
			//编写SQL语句
			String sql = "select * from project_list limit ?,?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setInt(1, begin);
			pstmt.setInt(2, limit);
			//执行
			rs = pstmt.executeQuery();
			//判断
			pageList = new ArrayList<ProJ>();
			while(rs.next()) {
				ProJ proJ = new ProJ();
				proJ.setProId(rs.getInt("id"));
				proJ.setProName(rs.getString("pro_name"));
				pageList.add(proJ);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return pageList;
	}

	@Override
	public ProJ deleteProName(String deleteProjectID) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "delete from project_list where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, deleteProjectID);
			pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(pstmt, conn);
		}
		return null;
	}





}
