package com.zj.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.zj.dao.UserDao;
import com.zj.domain.Guanli;
import com.zj.domain.Log;
import com.zj.domain.User;
import com.zj.utils.JDBCUtils;

public class UserDaoImpl implements UserDao {

	@Override
	public User userLogin(User user) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "select * from em_list where em_code = ? and em_password = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getUserCode());
			pstmt.setString(2, user.getUserPassword());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				User existUser = new User();
				existUser.setUserId(rs.getInt("em_id"));
				existUser.setUserCode(rs.getString("em_code"));
				existUser.setUserName(rs.getString("em_name"));;
				existUser.setUserPassword(rs.getString("em_password"));
				existUser.setUserPhone(rs.getString("em_phone_num"));;
				existUser.setUserPid(rs.getString("em_pid"));;
				return existUser;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return null;
	}

	@Override
	public List<User> findAllUser() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<User> list = null;
		try {
			//获取数据库连接
			conn = JDBCUtils.getConnection();
			//编写SQL语句
			String sql = "select * from em_list";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			//执行
			rs = pstmt.executeQuery();
			//判断
			list = new ArrayList<User>();
			while(rs.next()) {
				User user = new User();
				user.setUserId(rs.getInt("em_id"));
				user.setUserCode(rs.getString("em_code"));
				user.setUserName(rs.getString("em_name"));
				user.setUserPassword(rs.getString("em_password"));
				user.setUserPhone(rs.getString("em_phone_num"));
				user.setUserPid(rs.getString("em_pid"));
				list.add(user);
			}
			/*
			 * for(User u : list) { System.out.println(u.getUserName()); }
			 */
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return list;
	}


	@Override
	public User hxUser(Integer emId) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			//获取数据库连接
			conn = JDBCUtils.getConnection();
			//编写SQL语句
			String sql = "select * from em_list where em_id = ?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setInt(1, emId);
			//执行
			rs = pstmt.executeQuery();
			//判断
			if(rs.next()) {
				User huixianUser = new User();
				huixianUser.setUserCode(rs.getString("em_code"));
				huixianUser.setUserId(rs.getInt("em_id"));
				huixianUser.setUserName(rs.getString("em_name"));
				huixianUser.setUserPassword(rs.getString("em_password"));
				huixianUser.setUserPhone(rs.getString("em_phone_num"));
				huixianUser.setUserPid(rs.getString("em_pid"));
				return huixianUser;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return null;
	}

	@Override
	public User updateUser(User user) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();		
			String sql = "update em_list set em_name=?,em_phone_num=?,em_pid=?,em_code=? where em_id = ?";
			pstmt = conn.prepareStatement(sql);
			System.out.println("ceshi");
			System.out.println(user.getUserName());
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getUserPhone());
			pstmt.setString(3, user.getUserPid());
			pstmt.setString(4, user.getUserCode());
			pstmt.setInt(5, user.getUserId());
			pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(pstmt, conn);
		}
		return null;
	}

	@Override
	public List<User> likeSearchUser(String likeUser) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<User> likeList = null;
		try {
			//获取数据库连接
			/* System.out.println("进入daoImpl："+likeUser); */
			conn = JDBCUtils.getConnection();
			//编写SQL语句
			String sql = "select * from em_list where em_name like CONCAT('%',?,'%') or em_code like CONCAT('%',?,'%')";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setString(1, likeUser);
			pstmt.setString(2, likeUser);
			//执行
			rs = pstmt.executeQuery();
			//判断
			likeList = new ArrayList<User>();
			while(rs.next()) {
				User user = new User();
				user.setUserId(rs.getInt("em_id"));
				user.setUserCode(rs.getString("em_code"));
				user.setUserName(rs.getString("em_name"));
				user.setUserPassword(rs.getString("em_password"));
				user.setUserPhone(rs.getString("em_phone_num"));
				user.setUserPid(rs.getString("em_pid"));
				likeList.add(user);
			}
			/*
			 * for(User u : likeList) { System.out.println("for  " + u.getUserName()); }
			 */
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return likeList;
	}

	@Override
	public int findCount() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Long count = 0l; 
		try {
			//获取数据库连接
			conn = JDBCUtils.getConnection();
			//编写SQL语句:count是别名
			String sql = "select count(*) as count from em_list";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			//执行
			rs = pstmt.executeQuery();
			//判断
			if(rs.next()) {
				count = rs.getLong("count"); //count是别名&count是Long类型
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return count.intValue();  //将Long类型转换为Int类型
	}

	@Override
	public List<User> findByPage(int begin, int limit) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<User> pageList = null;
		try {
			conn = JDBCUtils.getConnection();
			//编写SQL语句
			String sql = "select * from em_list limit ?,?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setInt(1, begin);
			pstmt.setInt(2, limit);
			//执行
			rs = pstmt.executeQuery();
			//判断
			pageList = new ArrayList<User>();
			while(rs.next()) {
				User user = new User();
				user.setUserId(rs.getInt("em_id"));
				user.setUserCode(rs.getString("em_code"));
				user.setUserName(rs.getString("em_name"));
				user.setUserPassword(rs.getString("em_password"));
				user.setUserPhone(rs.getString("em_phone_num"));
				user.setUserPid(rs.getString("em_pid"));
				pageList.add(user);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return pageList;
	}

	@Override
	public Log addUserLog(Log userLog) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "insert into log_list(shangwu_xname,shangwu_plan,shangwu_status,xiawu_xname,xiawu_plan,xiawu_status,writer_user_name,writer_user_code) value(?,?,?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userLog.getShangwuPname());
			pstmt.setString(2, userLog.getShangwuPlan());
			pstmt.setString(3, userLog.getShangwuStatus());
			pstmt.setString(4, userLog.getXiawuPname());
			pstmt.setString(5, userLog.getXiawuPlan());
			pstmt.setString(6, userLog.getXiawuStatus());
			pstmt.setString(7, userLog.getWriterUserName());
			pstmt.setString(8, userLog.getWriterUserCode());
			pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(pstmt, conn);
		}
		return null;
	}

	@Override
	public Log updateUserLog(Log userUpLog) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "update log_list set shangwu_xname=?,shangwu_plan=?,shangwu_status=?,xiawu_xname=?,xiawu_plan=?,xiawu_status=? where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userUpLog.getShangwuPname());
			pstmt.setString(2, userUpLog.getShangwuPlan());
			pstmt.setString(3, userUpLog.getShangwuStatus());
			pstmt.setString(4, userUpLog.getXiawuPname());
			pstmt.setString(5, userUpLog.getXiawuPlan());
			pstmt.setString(6, userUpLog.getXiawuStatus());
			pstmt.setInt(7, userUpLog.getLogId());
			pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(pstmt, conn);
		}
		return null;
	}

	@Override
	public Log updateUserLogByTime(Log userUpLog) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "update log_list set shangwu_xname=?,shangwu_plan=?,shangwu_status=?,xiawu_xname=?,xiawu_plan=?,xiawu_status=? where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userUpLog.getShangwuPname());
			pstmt.setString(2, userUpLog.getShangwuPlan());
			pstmt.setString(3, userUpLog.getShangwuStatus());
			pstmt.setString(4, userUpLog.getXiawuPname());
			pstmt.setString(5, userUpLog.getXiawuPlan());
			pstmt.setString(6, userUpLog.getXiawuStatus());
			pstmt.setInt(7, userUpLog.getLogId());
			pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(pstmt, conn);
		}
		return null;
	}

	@Override
	public Log addAdminLog(Log userLog) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "insert into log_list(shangwu_xname,shangwu_plan,shangwu_status,xiawu_xname,xiawu_plan,xiawu_status,writer_admin_name,writer_admin_code) value(?,?,?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userLog.getShangwuPname());
			pstmt.setString(2, userLog.getShangwuPlan());
			pstmt.setString(3, userLog.getShangwuStatus());
			pstmt.setString(4, userLog.getXiawuPname());
			pstmt.setString(5, userLog.getXiawuPlan());
			pstmt.setString(6, userLog.getXiawuStatus());
			pstmt.setString(7, userLog.getWriterAdminName());
			pstmt.setString(8, userLog.getWriterAdminCode());
			pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(pstmt, conn);
		}
		return null;
	}

	@Override
	public User userForgetPassword(User userforget) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "select * from em_list where em_code = ? and em_name = ? and em_phone_num = ? and em_pid = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userforget.getUserCode());
			pstmt.setString(2, userforget.getUserName());
			pstmt.setString(3, userforget.getUserPhone());
			pstmt.setString(4, userforget.getUserPid());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				User existUserForget = new User();
				existUserForget.setUserId(rs.getInt("em_id"));;
				existUserForget.setUserName(rs.getString("em_name"));
				existUserForget.setUserCode(rs.getString("em_code"));
				existUserForget.setUserPhone(rs.getString("em_phone_num"));
				existUserForget.setUserPassword(rs.getString("em_password"));
				existUserForget.setUserPid(rs.getString("em_pid"));
				return existUserForget;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return null;
	}

	@Override
	public User userUpdatePassword(User userUpdatePassword) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			//获得连接
			conn = JDBCUtils.getConnection();
			String sql = "update em_list set em_password = ? where em_code = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userUpdatePassword.getUserPassword());
			pstmt.setString(2, userUpdatePassword.getUserCode());
			pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			JDBCUtils.release(pstmt, conn);
		}
		return null;
	}
}
