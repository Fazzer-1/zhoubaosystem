package com.zj.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.zj.dao.LogDao;
import com.zj.domain.Log;
import com.zj.utils.JDBCUtils;

public class LogDaoImpl implements LogDao {
	//用户查询自己的日志第1步
	@Override
	public int findCount(String userCodePage) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Long count = 0l; 
		try {
			//获取数据库连接
			conn = JDBCUtils.getConnection();
			//编写SQL语句:count是别名
			String sql = "select count(*) as count from log_list  where writer_user_code = ?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setString(1, userCodePage);
			//执行
			rs = pstmt.executeQuery();
			//判断
			if(rs.next()) {
				count = rs.getLong("count"); //count是别名&count是Long类型
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return count.intValue();  //将Long类型转换为Int类型
	}

	//用户查询自己的日志第2步
	@Override
	public List<Log> findByPage(int begin, int limit,String userCodePage) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Log> pageList = null;
		System.out.println(userCodePage);
		try {
			conn = JDBCUtils.getConnection();
			//编写SQL语句
			String sql = "select * from log_list where writer_user_code = ? limit ?,?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setString(1, userCodePage);
			pstmt.setInt(2, begin);
			pstmt.setInt(3, limit);
			//执行
			rs = pstmt.executeQuery();
			//判断
			pageList = new ArrayList<Log>();
			while(rs.next()) {
				Log log = new Log();
				log.setLogId(rs.getInt("id"));
				log.setShangwuPlan(rs.getString("shangwu_plan"));
				log.setShangwuPname(rs.getString("shangwu_xname"));
				log.setShangwuStatus(rs.getString("shangwu_status"));
				log.setTime(rs.getTimestamp("log_time"));
				log.setWriterUserCode(rs.getString("writer_user_code"));
				log.setWriterUserName(rs.getString("writer_user_name"));
				log.setXiawuPlan(rs.getString("xiawu_plan"));
				log.setXiawuPname(rs.getString("xiawu_xname"));
				log.setXiawuStatus(rs.getString("xiawu_status"));
				pageList.add(log);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return pageList;
	}

	@Override
	public int findCount(Timestamp startTime1, Timestamp endTime1, String timeUserCode) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Long count = 0l; 
		try {
			//获取数据库连接
			conn = JDBCUtils.getConnection();
			//编写SQL语句:count是别名
			String sql = "select count(*) as count from log_list  where writer_user_code=? and log_time between ? and ?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setString(1, timeUserCode);
			pstmt.setTimestamp(2, startTime1);
			pstmt.setTimestamp(3, endTime1);
			//执行
			rs = pstmt.executeQuery();
			//判断
			if(rs.next()) {
				count = rs.getLong("count"); //count是别名&count是Long类型
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return count.intValue();  //将Long类型转换为Int类型
	}

	@Override
	public List<Log> findByPage(int begin, int limit, Timestamp startTime1, Timestamp endTime1, String timeUserCode) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Log> pageList = null;
		try {
			conn = JDBCUtils.getConnection();
			System.out.println("aaa" + timeUserCode);
			System.out.println(timeUserCode);
			//编写SQL语句
			String sql = "select * from log_list where log_time between ? and ?  and writer_user_code=? limit ?,?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setTimestamp(1, startTime1);
			pstmt.setTimestamp(2, endTime1);
			
			pstmt.setString(3, timeUserCode);
			pstmt.setInt(4, begin);
			pstmt.setInt(5, limit);
			//执行
			rs = pstmt.executeQuery();
			//判断
			pageList = new ArrayList<Log>();
			while(rs.next()) {
				Log log = new Log();
				log.setLogId(rs.getInt("id"));
				log.setShangwuPlan(rs.getString("shangwu_plan"));
				log.setShangwuPname(rs.getString("shangwu_xname"));
				log.setShangwuStatus(rs.getString("shangwu_status"));
				log.setTime(rs.getTimestamp("log_time"));
				log.setWriterUserCode(rs.getString("writer_user_code"));
				log.setWriterUserName(rs.getString("writer_user_name"));
				log.setXiawuPlan(rs.getString("xiawu_plan"));
				log.setXiawuPname(rs.getString("xiawu_xname"));
				log.setXiawuStatus(rs.getString("xiawu_status"));
				pageList.add(log);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return pageList;
	}

	@Override
	public int adminFindSelfLogsCount(String adminCode) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Long count = 0l; 
		try {
			//获取数据库连接
			conn = JDBCUtils.getConnection();
			//编写SQL语句:count是别名
			String sql = "select count(*) as count from log_list  where writer_admin_code = ?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setString(1, adminCode);
			//执行
			rs = pstmt.executeQuery();
			//判断
			if(rs.next()) {
				count = rs.getLong("count"); //count是别名&count是Long类型
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return count.intValue();  //将Long类型转换为Int类型
	}

	@Override
	public List<Log> adminFindSelfLogsByPage(int begin, int limit, String adminCode) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Log> pageList = null;
		System.out.println(adminCode);
		try {
			conn = JDBCUtils.getConnection();
			//编写SQL语句
			String sql = "select * from log_list where writer_admin_code = ? limit ?,?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setString(1, adminCode);
			pstmt.setInt(2, begin);
			pstmt.setInt(3, limit);
			//执行
			rs = pstmt.executeQuery();
			//判断
			pageList = new ArrayList<Log>();
			while(rs.next()) {
				Log log = new Log();
				log.setLogId(rs.getInt("id"));
				log.setShangwuPlan(rs.getString("shangwu_plan"));
				log.setShangwuPname(rs.getString("shangwu_xname"));
				log.setShangwuStatus(rs.getString("shangwu_status"));
				log.setTime(rs.getTimestamp("log_time"));
				log.setWriterAdminCode(rs.getString("writer_admin_code"));
				log.setWriterAdminName(rs.getString("writer_admin_name"));
				log.setXiawuPlan(rs.getString("xiawu_plan"));
				log.setXiawuPname(rs.getString("xiawu_xname"));
				log.setXiawuStatus(rs.getString("xiawu_status"));
				pageList.add(log);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return pageList;
	}

	@Override
	public int adminFindSelfCount(Timestamp startTime1, Timestamp endTime1, String timeUserCode) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Long count = 0l; 
		try {
			//获取数据库连接
			conn = JDBCUtils.getConnection();
			//编写SQL语句:count是别名
			String sql = "select count(*) as count from log_list  where writer_admin_code=? and log_time between ? and ?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setString(1, timeUserCode);
			pstmt.setTimestamp(2, startTime1);
			pstmt.setTimestamp(3, endTime1);
			//执行
			rs = pstmt.executeQuery();
			//判断
			if(rs.next()) {
				count = rs.getLong("count"); //count是别名&count是Long类型
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return count.intValue();  //将Long类型转换为Int类型
	}

	@Override
	public List<Log> adminFindSelfByPage(int begin, int limit, Timestamp startTime1, Timestamp endTime1, String timeUserCode) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Log> pageList = null;
		try {
			conn = JDBCUtils.getConnection();
			System.out.println("aaa" + timeUserCode);
			System.out.println(timeUserCode);
			//编写SQL语句
			String sql = "select * from log_list where log_time between ? and ?  and writer_admin_code=? limit ?,?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setTimestamp(1, startTime1);
			pstmt.setTimestamp(2, endTime1);
			
			pstmt.setString(3, timeUserCode);
			pstmt.setInt(4, begin);
			pstmt.setInt(5, limit);
			//执行
			rs = pstmt.executeQuery();
			//判断
			pageList = new ArrayList<Log>();
			while(rs.next()) {
				Log log = new Log();
				log.setLogId(rs.getInt("id"));
				log.setShangwuPlan(rs.getString("shangwu_plan"));
				log.setShangwuPname(rs.getString("shangwu_xname"));
				log.setShangwuStatus(rs.getString("shangwu_status"));
				log.setTime(rs.getTimestamp("log_time"));
				log.setWriterAdminCode(rs.getString("writer_admin_code"));
				log.setWriterAdminName(rs.getString("writer_admin_name"));
				log.setXiawuPlan(rs.getString("xiawu_plan"));
				log.setXiawuPname(rs.getString("xiawu_xname"));
				log.setXiawuStatus(rs.getString("xiawu_status"));
				pageList.add(log);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return pageList;
	}

	@Override
	public int adminfindLogsByTimeCount(Timestamp startTime1, Timestamp endTime1) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Long count = 0l; 
		try {
			//获取数据库连接
			conn = JDBCUtils.getConnection();
			//编写SQL语句:count是别名
			String sql = "select count(*) as count from log_list  where log_time between ? and ?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setTimestamp(1, startTime1);
			pstmt.setTimestamp(2, endTime1);
			//执行
			rs = pstmt.executeQuery();
			//判断
			if(rs.next()) {
				count = rs.getLong("count"); //count是别名&count是Long类型
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return count.intValue();  //将Long类型转换为Int类型
	}

	@Override
	public List<Log> adminfindLogsByTimeCountByPage(int begin, int limit, Timestamp startTime1, Timestamp endTime1) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Log> pageList = null;
		try {
			conn = JDBCUtils.getConnection();
			//编写SQL语句
			String sql = "select * from log_list where log_time between ? and ? limit ?,?";
			//预编译
			pstmt = conn.prepareStatement(sql);
			//设置参数
			pstmt.setTimestamp(1, startTime1);
			pstmt.setTimestamp(2, endTime1);
			pstmt.setInt(3, begin);
			pstmt.setInt(4, limit);
			//执行
			rs = pstmt.executeQuery();
			//判断
			pageList = new ArrayList<Log>();
			while(rs.next()) {
				Log log = new Log();
				log.setLogId(rs.getInt("id"));
				log.setShangwuPlan(rs.getString("shangwu_plan"));
				log.setShangwuPname(rs.getString("shangwu_xname"));
				log.setShangwuStatus(rs.getString("shangwu_status"));
				log.setTime(rs.getTimestamp("log_time"));
				log.setWriterUserCode(rs.getString("writer_user_code"));
				log.setWriterUserName(rs.getString("writer_user_name"));
				log.setXiawuPlan(rs.getString("xiawu_plan"));
				log.setXiawuPname(rs.getString("xiawu_xname"));
				log.setXiawuStatus(rs.getString("xiawu_status"));
				pageList.add(log);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, pstmt, conn);
		}
		return pageList;
	}
}
