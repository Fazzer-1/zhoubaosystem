package com.zj.dao;

import java.util.List;

import com.zj.domain.Log;
import com.zj.domain.User;

public interface UserDao {

	User userLogin(User user);

	List<User> findAllUser();

	User hxUser(Integer emId);

	User updateUser(User user);

	List<User> likeSearchUser(String likeUser);

	int findCount();

	List<User> findByPage(int begin, int limit);
	
	//用户写日志
	Log addUserLog(Log userLog);

	Log updateUserLog(Log userUpLog);

	Log updateUserLogByTime(Log userUpLog);

	Log addAdminLog(Log userLog);

	User userForgetPassword(User userforget);

	User userUpdatePassword(User userUpdatePassword);





}
