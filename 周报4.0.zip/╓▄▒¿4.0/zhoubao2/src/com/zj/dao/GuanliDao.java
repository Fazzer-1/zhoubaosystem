package com.zj.dao;

import java.util.List;

import com.zj.domain.Guanli;
import com.zj.domain.PageBean;
import com.zj.domain.ProJ;
import com.zj.domain.User;

public interface GuanliDao {

	Guanli login(Guanli guanli) ;

	Guanli adminForgetPassword(Guanli guanliForget);

	Guanli adminUpdatePassword(Guanli guanliUpdatePassword);

	Guanli addUser(User addUser);

	Guanli deleteUser(Integer emId);

	ProJ addProName(ProJ proJ);

	int findProNamesCount();

	List<ProJ> findProNamesByPage(int begin, int limit);

	ProJ deleteProName(String deleteProjectID);



	


	

	

}
