package com.zj.service;

import java.sql.Timestamp;

import com.zj.domain.Guanli;
import com.zj.domain.Log;
import com.zj.domain.PageBean;
import com.zj.domain.ProJ;
import com.zj.domain.User;

public interface GuanliService {

	Guanli login(Guanli guanli);

	Guanli adminForgetPassword(Guanli guanliForget);

	Guanli adminUpdatePassword(Guanli guanliUpdatePassword);

	Guanli addUser(User addUser);

	Guanli deleteUser(Integer emId);

	ProJ addProName(ProJ proJ);

	PageBean<ProJ> lookAllProName(Integer page);

	ProJ deleteProName(String deleteProjectID);

	PageBean<Log> adminFindLogsByTime(int page, Timestamp startTime1, Timestamp endTime1);

	




}
