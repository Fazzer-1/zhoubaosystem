package com.zj.service;

import com.zj.domain.Log;
import com.zj.domain.PageBean;

public interface LogService {
	//用户查询自己日志--查询结果：列表
	PageBean<Log> findByPage(int page,String userCodePage);

	//管理员查自己的日志--查询结果：列表
	PageBean<Log> adminFindLogByPage(int page, String adminCode);


}
