package com.zj.service.impl;

import java.util.List;
import com.zj.dao.LogDao;
import com.zj.dao.impl.LogDaoImpl;
import com.zj.domain.Log;
import com.zj.domain.PageBean;
import com.zj.service.LogService;

public class LogServiceImpl implements LogService {
	@Override
	public PageBean<Log> findByPage(int page,String userCodePage) {
		PageBean<Log> userLogPageBean = new PageBean<Log>();
		//封装当前的页数：
		userLogPageBean.setPage(page);
		//封装每页显示记录数：
		int limit = 6;
		userLogPageBean.setLimit(limit);
		//封装总记录数：
		LogDao logDao = new LogDaoImpl();
		int totalCount = logDao.findCount(userCodePage);
		userLogPageBean.setTotalCount(totalCount);
		//封装总页数：
		int totalPage = 0;
		if(totalCount % limit == 0) {
			totalPage = totalCount / limit;
		}else{
			totalPage = totalCount / limit + 1;
		}
		System.out.println(totalPage);
		userLogPageBean.setTotalPage(totalPage);
		
		//封装每页显示数据的集合:
		int begin = (page - 1) * limit;
		
		List<Log> userLogPageBean1 = logDao.findByPage(begin,limit,userCodePage);
		userLogPageBean.setList(userLogPageBean1);
		return userLogPageBean;
	}

	@Override
	public PageBean<Log> adminFindLogByPage(int page, String adminCode) {
		PageBean<Log> adminLogPageBean = new PageBean<Log>();
		//封装当前的页数：
		adminLogPageBean.setPage(page);
		//封装每页显示记录数：
		int limit = 6;
		adminLogPageBean.setLimit(limit);
		//封装总记录数：
		LogDao logDao = new LogDaoImpl();
		int totalCount = logDao.adminFindSelfLogsCount(adminCode);
		adminLogPageBean.setTotalCount(totalCount);
		//封装总页数：
		int totalPage = 0;
		if(totalCount % limit == 0) {
			totalPage = totalCount / limit;
		}else{
			totalPage = totalCount / limit + 1;
		}
		System.out.println(totalPage);
		adminLogPageBean.setTotalPage(totalPage);
		
		//封装每页显示数据的集合:
		int begin = (page - 1) * limit;
		
		List<Log> userLogPageBean1 = logDao.adminFindSelfLogsByPage(begin,limit,adminCode);
		adminLogPageBean.setList(userLogPageBean1);
		return adminLogPageBean;
	}


}
