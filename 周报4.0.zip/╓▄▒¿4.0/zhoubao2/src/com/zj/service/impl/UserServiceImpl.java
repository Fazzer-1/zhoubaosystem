package com.zj.service.impl;

import java.sql.Timestamp;
import java.util.List;

import com.zj.dao.LogDao;
import com.zj.dao.UserDao;
import com.zj.dao.impl.LogDaoImpl;
import com.zj.dao.impl.UserDaoImpl;
import com.zj.domain.Log;
import com.zj.domain.PageBean;
import com.zj.domain.User;
import com.zj.service.UserService;

public class UserServiceImpl implements UserService {

	@Override
	public User userLogin(User user) {
		UserDao userDao = new UserDaoImpl();
		return userDao.userLogin(user);
	}

	@Override
	public List<User> findAllUser() {
		UserDao userDao = new UserDaoImpl();
		return userDao.findAllUser();
	}


	@Override
	public User hxUser(Integer emId) {
		UserDao userDao = new UserDaoImpl();
		return userDao.hxUser(emId);
	}

	@Override
	public User updateUser(User user) {
		UserDao userDao = new UserDaoImpl();
		return userDao.updateUser(user);
	}

	@Override
	public List<User> likeSearchUser(String likeUser) {
		UserDao userDao = new UserDaoImpl();
		return userDao.likeSearchUser(likeUser);
	}

	@Override
	public PageBean<User> findByPage(int page) {
		PageBean<User> pageBean = new PageBean<User>();
		//封装当前的页数：
		pageBean.setPage(page);
		//封装每页显示记录数：
		int limit = 6;
		pageBean.setLimit(limit);
		//封装总记录数：
		UserDao userDao = new UserDaoImpl();
		int totalCount = userDao.findCount();
		pageBean.setTotalCount(totalCount);
		//封装总页数：
		int totalPage = 0;
		if(totalCount % limit == 0) {
			totalPage = totalCount / limit;
		}else{
			totalPage = totalCount / limit + 1;
		}
		System.out.println(totalPage);
		pageBean.setTotalPage(totalPage);
		
		//封装每页显示数据的集合:
		int begin = (page - 1) * limit;
		List<User> userPageList = userDao.findByPage(begin,limit);
		pageBean.setList(userPageList);
		return pageBean;
	}

	@Override
	public Log addUserLog(Log userLog) {
		UserDao userDao = new UserDaoImpl();
		return userDao.addUserLog(userLog);
	}

	@Override
	public Log updateUserLog(Log userUpLog) {
		UserDao userDao = new UserDaoImpl();
		return userDao.updateUserLog(userUpLog);
	}

	@Override
	public PageBean<Log> userFindLogByTime(int page, Timestamp startTime1, Timestamp endTime1, String timeUserCode) {
		PageBean<Log> userLogTime = new PageBean<Log>();
		//封装当前的页数：
		userLogTime.setPage(page);
		//封装每页显示记录数：
		int limit = 6;
		userLogTime.setLimit(limit);
		//封装总记录数：
		LogDao logDao = new LogDaoImpl();
		int totalCount = logDao.findCount(startTime1,endTime1,timeUserCode);
		userLogTime.setTotalCount(totalCount);
		//封装总页数：
		int totalPage = 0;
		if(totalCount % limit == 0) {
			totalPage = totalCount / limit;
		}else{
			totalPage = totalCount / limit + 1;
		}
		System.out.println(totalPage);
		userLogTime.setTotalPage(totalPage);
		
		//封装每页显示数据的集合:
		int begin = (page - 1) * limit;
		
		List<Log> userLogPageBean1 = logDao.findByPage(begin,limit,startTime1,endTime1,timeUserCode);
		userLogTime.setList(userLogPageBean1);
		return userLogTime;
	}

	@Override
	public Log updateUserLogByTime(Log userUpLog) {
		UserDao userDao = new UserDaoImpl();
		return userDao.updateUserLogByTime(userUpLog);
	}

	@Override
	public Log addAdminLog(Log userLog) {
		UserDao userDao = new UserDaoImpl();
		return userDao.addAdminLog(userLog);
	}

	@Override
	public User userForgetPassword(User userforget) {
		UserDao userDao = new UserDaoImpl();
		return userDao.userForgetPassword(userforget);
	}

	@Override
	public User userUpdatePassword(User userUpdatePassword) {
		UserDao userDao = new UserDaoImpl();
		return userDao.userUpdatePassword(userUpdatePassword);
	}

	@Override
	public PageBean<Log> adminFindSelfLogByTime(int page, Timestamp startTime1, Timestamp endTime1, String timeUserCode) {
		PageBean<Log> adminLogTime = new PageBean<Log>();
		//封装当前的页数：
		adminLogTime.setPage(page);
		//封装每页显示记录数：
		int limit = 6;
		adminLogTime.setLimit(limit);
		//封装总记录数：
		LogDao logDao = new LogDaoImpl();
		int totalCount = logDao.adminFindSelfCount(startTime1,endTime1,timeUserCode);
		adminLogTime.setTotalCount(totalCount);
		//封装总页数：
		int totalPage = 0;
		if(totalCount % limit == 0) {
			totalPage = totalCount / limit;
		}else{
			totalPage = totalCount / limit + 1;
		}
		System.out.println(totalPage);
		adminLogTime.setTotalPage(totalPage);
		
		//封装每页显示数据的集合:
		int begin = (page - 1) * limit;
		
		List<Log> userLogPageBean1 = logDao.adminFindSelfByPage(begin,limit,startTime1,endTime1,timeUserCode);
		adminLogTime.setList(userLogPageBean1);
		return adminLogTime;
	}

	



}
