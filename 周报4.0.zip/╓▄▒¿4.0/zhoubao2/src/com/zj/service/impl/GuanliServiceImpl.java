package com.zj.service.impl;

import java.sql.Timestamp;
import java.util.List;

import com.zj.dao.GuanliDao;
import com.zj.dao.LogDao;
import com.zj.dao.UserDao;
import com.zj.dao.impl.GuanliDaoImpl;
import com.zj.dao.impl.LogDaoImpl;
import com.zj.dao.impl.UserDaoImpl;
import com.zj.domain.Guanli;
import com.zj.domain.Log;
import com.zj.domain.PageBean;
import com.zj.domain.ProJ;
import com.zj.domain.User;
import com.zj.service.GuanliService;

public class GuanliServiceImpl implements GuanliService {

	@Override
	public Guanli login(Guanli guanli)  {
		//调用DAO的方法查询用户是否存在：
		GuanliDao guanliDao = new GuanliDaoImpl();
		return guanliDao.login(guanli);
	}

	@Override
	public Guanli adminForgetPassword(Guanli guanliForget) {
		//调用DAO的方法查询前台页面填写的管理员账户信息是否属实
		GuanliDao guanliForgetDao = new GuanliDaoImpl();
		return guanliForgetDao.adminForgetPassword(guanliForget);
	}

	@Override
	public Guanli adminUpdatePassword(Guanli guanliUpdatePassword) {
		//调用DAO的方法更新数据库中管理员密码
		GuanliDao guanliUpdatePasswordDao = new GuanliDaoImpl();
		return guanliUpdatePasswordDao.adminUpdatePassword(guanliUpdatePassword);
	}

	@Override
	public Guanli addUser(User addUser) {
		// TODO Auto-generated method stub
		GuanliDao addUserDao = new GuanliDaoImpl();
		return addUserDao.addUser(addUser);
	}

	@Override
	public Guanli deleteUser(Integer emId) {
		GuanliDao deleteUserDao = new GuanliDaoImpl();
		return deleteUserDao.deleteUser(emId);
		
	}

	@Override
	public ProJ addProName(ProJ proJ) {
		GuanliDao guanliDao = new GuanliDaoImpl();
		return guanliDao.addProName(proJ);
	}

	@Override
	public PageBean<ProJ> lookAllProName(Integer page) {
		PageBean<ProJ> pageBean = new PageBean<ProJ>();
		//封装当前的页数：
		pageBean.setPage(page);
		//封装每页显示记录数：
		int limit = 6;
		pageBean.setLimit(limit);
		//封装总记录数：
		GuanliDao guanliDao = new GuanliDaoImpl();
		int totalCount = guanliDao.findProNamesCount();
		pageBean.setTotalCount(totalCount);
		//封装总页数：
		int totalPage = 0;
		if(totalCount % limit == 0) {
			totalPage = totalCount / limit;
		}else{
			totalPage = totalCount / limit + 1;
		}
		System.out.println(totalPage);
		pageBean.setTotalPage(totalPage);
		
		//封装每页显示数据的集合:
		int begin = (page - 1) * limit;
		List<ProJ> proJectNames = guanliDao.findProNamesByPage(begin,limit);
		pageBean.setList(proJectNames);
		return pageBean;
	}

	@Override
	public ProJ deleteProName(String deleteProjectID) {
		GuanliDao guanliDao = new GuanliDaoImpl();
		return guanliDao.deleteProName(deleteProjectID);
	}

	@Override
	public PageBean<Log> adminFindLogsByTime(int page, Timestamp startTime1, Timestamp endTime1) {
		PageBean<Log> adminLogTime = new PageBean<Log>();
		//封装当前的页数：
		adminLogTime.setPage(page);
		//封装每页显示记录数：
		int limit = 6;
		adminLogTime.setLimit(limit);
		//封装总记录数：
		LogDao logDao = new LogDaoImpl();
		int totalCount = logDao.adminfindLogsByTimeCount(startTime1,endTime1);
		adminLogTime.setTotalCount(totalCount);
		//封装总页数：
		int totalPage = 0;
		if(totalCount % limit == 0) {
			totalPage = totalCount / limit;
		}else{
			totalPage = totalCount / limit + 1;
		}
		System.out.println(totalPage);
		adminLogTime.setTotalPage(totalPage);
		
		//封装每页显示数据的集合:
		int begin = (page - 1) * limit;
		
		List<Log> userLogPageBean1 = logDao.adminfindLogsByTimeCountByPage(begin,limit,startTime1,endTime1);
		adminLogTime.setList(userLogPageBean1);
		return adminLogTime;
	}

	


}
