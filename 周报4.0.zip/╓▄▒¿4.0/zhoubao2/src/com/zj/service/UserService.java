package com.zj.service;

import java.sql.Timestamp;
import java.util.List;

import com.zj.domain.Log;
import com.zj.domain.PageBean;
import com.zj.domain.User;

public interface UserService {

	User userLogin(User user);

	List<User> findAllUser();

	User hxUser(Integer emId);

	User updateUser(User user);

	List<User> likeSearchUser(String likeUser);

	//用户分页查询
	PageBean<User> findByPage(int page);

	//用户写日志
	Log addUserLog(Log userLog);

	//用户修改日志
	Log updateUserLog(Log userUpLog);

	//用户根据时间范围查找日志--分页查询
	PageBean<Log> userFindLogByTime(int page, Timestamp startTime1, Timestamp endTime1, String timeUserCode);
	//用户根据时间范围查找日志--修改日志
	Log updateUserLogByTime(Log userUpLog);
	
	//管理员写日志
	Log addAdminLog(Log userLog);

	//用户忘记密码--第一步：验证
	User userForgetPassword(User userforget);

	User userUpdatePassword(User userUpdatePassword);
	
	////用户根据时间范围查找日志--分页查询
	PageBean<Log> adminFindSelfLogByTime(int page, Timestamp startTime1, Timestamp endTime1, String timeUserCode);
}
