package com.zj.web.action;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.zj.domain.Guanli;
import com.zj.domain.Log;
import com.zj.domain.PageBean;
import com.zj.domain.ProJ;
import com.zj.domain.Shijian;
import com.zj.domain.User;
import com.zj.service.GuanliService;
import com.zj.service.LogService;
import com.zj.service.UserService;
import com.zj.service.impl.GuanliServiceImpl;
import com.zj.service.impl.LogServiceImpl;
import com.zj.service.impl.UserServiceImpl;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 * Servlet implementation class GuanliServlet
 */
@WebServlet("/GuanliServlet")
public class GuanliServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//新密码的账号
	String updatePasswordCode = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接收参数
		String methodName = request.getParameter("method");
		//判断
		if("login".equals(methodName)) {
			login(request,response);
		}else if("adminForgetPassword".equals(methodName)) {
			adminForgetPassword(request,response);
		}else if("adminUpdatePassword".equals(methodName)) {
			adminUpdatePassword(request,response);
		}else if("addUser".equals(methodName)) {
			addUser(request,response);
		}else if("adminLogout".equals(methodName)) {
			adminLogout(request,response);
		}else if("deleteUser".equals(methodName)) {
			deleteUser(request,response);
		}else if("huixianUser".equals(methodName)) {
			huixianUser(request,response);
		}else if("updateUser".equals(methodName)) {
			updateUser(request,response);
		}else if("searchUser".equals(methodName)) {
			searchUser(request,response);
		}else if("adminXieLog".equals(methodName)) {
			adminXieLog(request,response);
		}else if("adminLookSelfLogs".equals(methodName)) {
			adminLookSelfLogs(request,response);
		}else if("adminFindOneLog".equals(methodName)) {
			try {
				adminFindOneLog(request,response);
			} catch (ParseException | ServletException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("adminUpdateSelfLog".equals(methodName)) {
			adminUpdateSelfLog(request,response);
		}else if("adminFindSelfLogByTime".equals(methodName)) {
			try {
				adminFindSelfLogByTime(request,response);
			} catch (ParseException | ServletException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("adminFindSelfOneLogByTime".equals(methodName)) {
			try {
				adminFindSelfOneLogByTime(request,response);
			} catch (ServletException | IOException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("adminUpdateSelfLogByTime".equals(methodName)) {
			adminUpdateSelfLogByTime(request,response);
		}else if("findOneUserLog".equals(methodName)) {
			findOneUserLog(request,response);
		}else if("adminFindOneUserOneLog".equals(methodName)) {
			try {
				adminFindOneUserOneLog(request,response);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("adminFindOneUserLogsByTime".equals(methodName)) {
			try {
				adminFindOneUserLogsByTime(request,response);
			} catch (ParseException | ServletException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("adminLookOneUserOneLogByTime".equals(methodName)) {
			try {
				adminLookOneUserOneLogByTime(request,response);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("addProject".equals(methodName)) {
			addProject(request,response);
		}else if("lookProNames".equals(methodName)) {
			lookProNames(request,response);
		}else if("deleteProject".equals(methodName)) {
			deleteProject(request,response);
		}else if("adminLookAllLogsByTime".equals(methodName)) {
			try {
				adminLookAllLogsByTime(request,response);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	//管理员根据时间查出一天内的所有日志
	private void adminLookAllLogsByTime(HttpServletRequest request, HttpServletResponse response) throws ParseException, ServletException, IOException {
		String startTime = request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		//赋值
		Shijian shijian = new Shijian();
		shijian.setKaishiTime(startTime);
		shijian.setJieshuTime(endTime);
		request.getSession().setAttribute("shijian", shijian);
		//转换类型
		String a =startTime.substring(0, 4).concat(startTime.substring(5, 7));
		String b =a.concat(startTime.substring(8, 10));
		String c = "000000";
		String d = b.concat(c);
		DateFormat format1 = new SimpleDateFormat("yyyyMMddHHmmss");
		Timestamp startTime1 = new Timestamp(format1.parse(d).getTime());
		
		
		/*
		 * //String转成date //获得一个时间格式的字符串 String dateStr = startTime.substring(0, 4) +
		 * "-" + startTime.substring(5, 7) + "-" + startTime.substring(8, 10);
		 * //获得SimpleDateFormat类，我们转换为yyyy-MM-dd的时间格式 SimpleDateFormat sf = new
		 * SimpleDateFormat("yyyy-MM-dd"); Date kaishidate = sf.parse(dateStr);
		 */
		String lookTime = startTime.substring(0, 4) + "/" + startTime.substring(5, 7) + "/" + startTime.substring(8, 10) + "/";
		System.out.println(lookTime);
		request.setAttribute("lookTime", lookTime);
		
		String e =endTime.substring(0, 4).concat(endTime.substring(5, 7));
		String f =e.concat(endTime.substring(8, 10));
		String g = "000000";
		String q = f.concat(g);
		DateFormat format2 = new SimpleDateFormat("yyyyMMddHHmmss");
		Timestamp endTime1 = new Timestamp(format2.parse(q).getTime());
		System.out.println(endTime1);
		//处理数据
		int page = 0;
		String currPage = request.getParameter("page");
		if(currPage == null) {
			page = 1;
		}else {
			page = Integer.parseInt(currPage);
		}
		GuanliService guanliService = new GuanliServiceImpl();
		PageBean<Log> adminLookLogsByTimePageBean = guanliService.adminFindLogsByTime(page,startTime1,endTime1);
		System.out.println(adminLookLogsByTimePageBean);
		request.setAttribute("adminLookLogsByTimePageBean", adminLookLogsByTimePageBean);
		request.getRequestDispatcher("/journal/adminLookAllLogByTime.jsp").forward(request, response);
		
	}



	//管理员删除项目名称
	private void deleteProject(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String deleteProjectID = request.getParameter("proID");
		System.out.println(deleteProjectID);
		GuanliService guanliService = new GuanliServiceImpl();
		guanliService.deleteProName(deleteProjectID);
		response.sendRedirect(request.getContextPath() + "/GuanliServlet?method=lookProNames");
	}

	//管理员查看所有项目名称
	private void lookProNames(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int page = 0;
		String currPage = request.getParameter("page");
		if(currPage == null) {
			page = 1;
		}else {
			page = Integer.parseInt(currPage);
		}
		GuanliService guanliService = new GuanliServiceImpl();
		PageBean<ProJ> proNamesPageBean = guanliService.lookAllProName(page);
		
		System.out.println(proNamesPageBean);
		request.setAttribute("proNamesPageBean", proNamesPageBean);
		request.getRequestDispatcher("/project/adminLookProject.jsp").forward(request, response);
		
		
	}

	//管理员添加项目名称
	private void addProject(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String projectName = request.getParameter("projectName");
		ProJ proJ = new ProJ();
		proJ.setProName(projectName);
		GuanliService guanliService = new GuanliServiceImpl();
		guanliService.addProName(proJ);
		response.sendRedirect(request.getContextPath() + "/GuanliServlet?method=lookProNames");
	}

	//管理员根据时间查看一个用户的单个日志
	private void adminLookOneUserOneLogByTime(HttpServletRequest request, HttpServletResponse response) throws ParseException, ServletException, IOException {
		DateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
		//接收数据
		Integer userLogId3 = Integer.parseInt(request.getParameter("userLogId3"));
		Timestamp userLogTime3 = new Timestamp(format.parse(request.getParameter("userLogTime3")).getTime());
		String userLogShangwuPname3 = request.getParameter("userLogShangwuPname3");
		String userLogShangwuPlan3 = request.getParameter("userLogShangwuPlan3");
		String userLogShangwuStatus3 = request.getParameter("userLogShangwuStatus3");
		String userLogXiawuPname3 = request.getParameter("userLogXiawuPname3");
		String userLogXiawuPlan3 = request.getParameter("userLogXiawuPlan3");
		String userLogXiawuStatus3 = request.getParameter("userLogXiawuStatus3");
		String userLogUserCode3 = request.getParameter("userLogUserCode3");
		String userLogUserName3 = request.getParameter("userLogUserName3");
		System.out.println(userLogTime3);
		//封装数据
		Log adminLookOneUserOneLogByTime1 = new Log();
		adminLookOneUserOneLogByTime1.setLogId(userLogId3);
		adminLookOneUserOneLogByTime1.setTime(userLogTime3);
		adminLookOneUserOneLogByTime1.setShangwuPname(userLogShangwuPname3);
		adminLookOneUserOneLogByTime1.setShangwuPlan(userLogShangwuPlan3);
		adminLookOneUserOneLogByTime1.setShangwuStatus(userLogShangwuStatus3);
		adminLookOneUserOneLogByTime1.setXiawuPname(userLogXiawuPname3);
		adminLookOneUserOneLogByTime1.setXiawuPlan(userLogXiawuPlan3);
		adminLookOneUserOneLogByTime1.setXiawuStatus(userLogXiawuStatus3);
		adminLookOneUserOneLogByTime1.setWriterUserCode(userLogUserCode3);
		adminLookOneUserOneLogByTime1.setWriterUserName(userLogUserName3);
		//页面跳转
		request.getSession().setAttribute("adminLookOneUserOneLogByTime1", adminLookOneUserOneLogByTime1);
		request.getRequestDispatcher("/journal/adminLookOneUserOneLogByTime.jsp").forward(request,response);
		
	}

	//管理员根据时间查看一个用户的所有日志
	private void adminFindOneUserLogsByTime(HttpServletRequest request, HttpServletResponse response) throws ParseException, ServletException, IOException {
		String startTime = request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		String timeUserCode = request.getParameter("adminLookOneUserLogByTime");
		request.getSession().setAttribute("timeUserCode1", timeUserCode);
		System.out.println("获取数据"+timeUserCode);
		//赋值
		Shijian shijian = new Shijian();
		shijian.setKaishiTime(startTime);
		shijian.setJieshuTime(endTime);
		request.getSession().setAttribute("shijian", shijian);
		//转换类型
		String a =startTime.substring(0, 4).concat(startTime.substring(5, 7));
		String b =a.concat(startTime.substring(8, 10));
		String c = "000000";
		String d = b.concat(c);
		DateFormat format1 = new SimpleDateFormat("yyyyMMddHHmmss");
		Timestamp startTime1 = new Timestamp(format1.parse(d).getTime());
		System.out.println(startTime1);
		String e =endTime.substring(0, 4).concat(endTime.substring(5, 7));
		String f =e.concat(endTime.substring(8, 10));
		String g = "000000";
		String q = f.concat(g);
		DateFormat format2 = new SimpleDateFormat("yyyyMMddHHmmss");
		Timestamp endTime1 = new Timestamp(format2.parse(q).getTime());
		System.out.println(endTime1);
		//处理数据
		int page = 0;
		String currPage = request.getParameter("page");
		if(currPage == null) {
			page = 1;
		}else {
			page = Integer.parseInt(currPage);
		}
		UserService userService = new UserServiceImpl();
		PageBean<Log> userLookLogByTimePageBean = userService.userFindLogByTime(page,startTime1,endTime1,timeUserCode);
		System.out.println(userLookLogByTimePageBean);
		request.setAttribute("adminLookOneUserLogsByTime", userLookLogByTimePageBean);
		request.getRequestDispatcher("/journal/adminLookOneUserLogsByTime.jsp").forward(request, response);
		
	}

	//管理员查看一个用户的单个日志细则
	private void adminFindOneUserOneLog(HttpServletRequest request, HttpServletResponse response) throws ParseException, ServletException, IOException {
		DateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
		//接收数据
		Integer userLogId1 = Integer.parseInt(request.getParameter("userLogId1"));
		Timestamp userLogTime1 = new Timestamp(format.parse(request.getParameter("userLogTime1")).getTime());
		String userLogShangwuPname1 = request.getParameter("userLogShangwuPname1");
		String userLogShangwuPlan1 = request.getParameter("userLogShangwuPlan1");
		String userLogShangwuStatus1 = request.getParameter("userLogShangwuStatus1");
		String userLogXiawuPname1 = request.getParameter("userLogXiawuPname1");
		String userLogXiawuPlan1 = request.getParameter("userLogXiawuPlan1");
		String userLogXiawuStatus1 = request.getParameter("userLogXiawuStatus1");
		String userLogUserCode1 = request.getParameter("userLogUserCode1");
		String userLogUserName1 = request.getParameter("userLogUserName1");
		System.out.println(userLogTime1);
		//封装数据	
		Log findOneLog = new Log();
		findOneLog.setLogId(userLogId1);
		findOneLog.setTime(userLogTime1);
		findOneLog.setShangwuPname(userLogShangwuPname1);
		findOneLog.setShangwuPlan(userLogShangwuPlan1);
		findOneLog.setShangwuStatus(userLogShangwuStatus1);
		findOneLog.setXiawuPname(userLogXiawuPname1);
		findOneLog.setXiawuPlan(userLogXiawuPlan1);
		findOneLog.setXiawuStatus(userLogXiawuStatus1);
		findOneLog.setWriterUserCode(userLogUserCode1);
		findOneLog.setWriterUserName(userLogUserName1);
		//页面跳转
		request.getSession().setAttribute("adminFindOneUserOneLog", findOneLog);
		request.getRequestDispatcher("/journal/adminLookOneUserOneLog.jsp").forward(request,response);
		
	}

	//管理员查看一个用户的所有日志
	private void findOneUserLog(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int page = 0;
		String userCodePage = request.getParameter("userCode");
		request.setAttribute("adminLookOneUserLogUserCode", userCodePage);
		System.out.println("aini" + userCodePage);
		String currPage = request.getParameter("page");
		if(currPage == null) {
			page = 1;
		}else {
			page = Integer.parseInt(currPage);
		}
		LogService logService = new LogServiceImpl();
		PageBean<Log> adminFindOneUserLogs = logService.findByPage(page,userCodePage);
		System.out.println(adminFindOneUserLogs);
		request.setAttribute("adminFindOneUserLogs", adminFindOneUserLogs);
		request.getRequestDispatcher("/journal/adminLookOneUserLogs.jsp").forward(request, response);
		
	}

	//管理员根据时间范围查询自己的日志--查看单个日志的细则--修改自己的日志
	private void adminUpdateSelfLogByTime(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String projectNameShangwu2 = request.getParameter("projectNameShangwu2");
		String shangwuStatus2 = request.getParameter("shangwuStatus2");
		String shangwuPlan2 = request.getParameter("shangwuPlan2");
		String projectNameXiawu2 = request.getParameter("projectNameXiawu2");
		String xiawuStatus2 = request.getParameter("xiawuStatus2");
		String xiawuJihua2 = request.getParameter("xiawuJihua2");
		Integer logId2 = Integer.parseInt(request.getParameter("logId2"));
		//封装数据
		Log adminUpLog = new Log();
		adminUpLog.setShangwuPname(projectNameShangwu2);
		adminUpLog.setShangwuPlan(shangwuPlan2);
		adminUpLog.setShangwuStatus(shangwuStatus2);
		adminUpLog.setXiawuPname(projectNameXiawu2);
		adminUpLog.setXiawuPlan(xiawuJihua2);
		adminUpLog.setXiawuStatus(xiawuStatus2);
		adminUpLog.setLogId(logId2);
		//处理数据
		UserService userService = new UserServiceImpl();
		userService.updateUserLog(adminUpLog);
		//页面跳转
		response.sendRedirect(request.getContextPath() + "/main.jsp");
		
	}

	//管理员根据时间范围查询自己的日志--查看单个日志的细则
	private void adminFindSelfOneLogByTime(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ParseException {
		DateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
		//接收数据
		Integer adminLogId3 = Integer.parseInt(request.getParameter("adminLogId3"));
		Timestamp adminLogTime3 = new Timestamp(format.parse(request.getParameter("adminLogTime3")).getTime());
		String adminLogShangwuPname3 = request.getParameter("adminLogShangwuPname3");
		String adminLogShangwuPlan3 = request.getParameter("adminLogShangwuPlan3");
		String adminLogShangwuStatus3 = request.getParameter("adminLogShangwuStatus3");
		String adminLogXiawuPname3 = request.getParameter("adminLogXiawuPname3");
		String adminLogXiawuPlan3 = request.getParameter("adminLogXiawuPlan3");
		String adminLogXiawuStatus3 = request.getParameter("adminLogXiawuStatus3");
		String adminLogAdminCode3 = request.getParameter("adminLogAdminCode3");
		String adminLogAdminName3 = request.getParameter("adminLogAdminName3");
		//封装数据
		Log adminTimeSelfLog = new Log();
		adminTimeSelfLog.setLogId(adminLogId3);
		adminTimeSelfLog.setTime(adminLogTime3);
		adminTimeSelfLog.setShangwuPname(adminLogShangwuPname3);
		adminTimeSelfLog.setShangwuPlan(adminLogShangwuPlan3);
		adminTimeSelfLog.setShangwuStatus(adminLogShangwuStatus3);
		adminTimeSelfLog.setXiawuPname(adminLogXiawuPname3);
		adminTimeSelfLog.setXiawuPlan(adminLogXiawuPlan3);
		adminTimeSelfLog.setXiawuStatus(adminLogXiawuStatus3);
		adminTimeSelfLog.setWriterAdminCode(adminLogAdminCode3);
		adminTimeSelfLog.setWriterAdminName(adminLogAdminName3);
		//页面跳转
		request.getSession().setAttribute("adminFindSelfOneLogByTime", adminTimeSelfLog);
		request.getRequestDispatcher("/journal/adminUpdateSelfLogByTime.jsp").forward(request,response);
		
	}

	//管理员根据时间范围查询自己的日志--列表
	private void adminFindSelfLogByTime(HttpServletRequest request, HttpServletResponse response) throws ParseException, ServletException, IOException {
		String startTime = request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		String timeUserCode = request.getParameter("timeUserCode");
		//赋值
		Shijian shijian = new Shijian();
		shijian.setKaishiTime(startTime);
		shijian.setJieshuTime(endTime);
		request.getSession().setAttribute("shijian", shijian);
		//转换类型
		String a =startTime.substring(0, 4).concat(startTime.substring(5, 7));
		String b =a.concat(startTime.substring(8, 10));
		String c = "000000";
		String d = b.concat(c);
		DateFormat format1 = new SimpleDateFormat("yyyyMMddHHmmss");
		Timestamp startTime1 = new Timestamp(format1.parse(d).getTime());
		System.out.println(startTime1);
		String e =endTime.substring(0, 4).concat(endTime.substring(5, 7));
		String f =e.concat(endTime.substring(8, 10));
		String g = "000000";
		String q = f.concat(g);
		DateFormat format2 = new SimpleDateFormat("yyyyMMddHHmmss");
		Timestamp endTime1 = new Timestamp(format2.parse(q).getTime());
		System.out.println(endTime1);
		//处理数据
		int page = 0;
		String currPage = request.getParameter("page");
		if(currPage == null) {
			page = 1;
		}else {
			page = Integer.parseInt(currPage);
		}
		UserService adminService = new UserServiceImpl();
		PageBean<Log> adminLookSelfLogByTimePageBean = adminService.adminFindSelfLogByTime(page,startTime1,endTime1,timeUserCode);
		/* System.out.println(adminLookSelfLogByTimePageBean); */
		request.setAttribute("adminLookSelfLogByTimePageBean", adminLookSelfLogByTimePageBean);
		request.getRequestDispatcher("/journal/adminLookSelfLogByTime.jsp").forward(request, response);
		
	}

	//管理员修改自己的日志
	private void adminUpdateSelfLog(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String projectNameShangwu2 = request.getParameter("projectNameShangwu2");
		String shangwuStatus2 = request.getParameter("shangwuStatus2");
		String shangwuPlan2 = request.getParameter("shangwuPlan2");
		String projectNameXiawu2 = request.getParameter("projectNameXiawu2");
		String xiawuStatus2 = request.getParameter("xiawuStatus2");
		String xiawuJihua2 = request.getParameter("xiawuJihua2");
		Integer logId2 = Integer.parseInt(request.getParameter("logId2"));
		//封装数据
		Log adminUpLog = new Log();
		adminUpLog.setShangwuPname(projectNameShangwu2);
		adminUpLog.setShangwuPlan(shangwuPlan2);
		adminUpLog.setShangwuStatus(shangwuStatus2);
		adminUpLog.setXiawuPname(projectNameXiawu2);
		adminUpLog.setXiawuPlan(xiawuJihua2);
		adminUpLog.setXiawuStatus(xiawuStatus2);
		adminUpLog.setLogId(logId2);
		//处理数据
		UserService userService = new UserServiceImpl();
		userService.updateUserLog(adminUpLog);
		//页面跳转
		response.sendRedirect(request.getContextPath() + "/main.jsp");
	}

	//管理员查看自己的单个日志--查看具体
	private void adminFindOneLog(HttpServletRequest request, HttpServletResponse response) throws ParseException, ServletException, IOException {
		DateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
		//接收数据
		Integer adminLogId1 = Integer.parseInt(request.getParameter("adminLogId1"));
		Timestamp adminLogTime1 = new Timestamp(format.parse(request.getParameter("adminLogTime1")).getTime());
		String adminLogShangwuPname1 = request.getParameter("adminLogShangwuPname1");
		String adminLogShangwuPlan1 = request.getParameter("adminLogShangwuPlan1");
		String adminLogShangwuStatus1 = request.getParameter("adminLogShangwuStatus1");
		String adminLogXiawuPname1 = request.getParameter("adminLogXiawuPname1");
		String adminLogXiawuPlan1 = request.getParameter("adminLogXiawuPlan1");
		String adminLogXiawuStatus1 = request.getParameter("adminLogXiawuStatus1");
		String adminLogUserCode1 = request.getParameter("adminLogUserCode1");
		String adminLogUserName1 = request.getParameter("adminLogUserName1");
		System.out.println(adminLogTime1);
		//封装数据	
		Log adminFindOneLog = new Log();
		adminFindOneLog.setLogId(adminLogId1);
		adminFindOneLog.setTime(adminLogTime1);
		adminFindOneLog.setShangwuPname(adminLogShangwuPname1);
		adminFindOneLog.setShangwuPlan(adminLogShangwuPlan1);
		adminFindOneLog.setShangwuStatus(adminLogShangwuStatus1);
		adminFindOneLog.setXiawuPname(adminLogXiawuPname1);
		adminFindOneLog.setXiawuPlan(adminLogXiawuPlan1);
		adminFindOneLog.setXiawuStatus(adminLogXiawuStatus1);
		adminFindOneLog.setWriterAdminCode(adminLogUserCode1);
		adminFindOneLog.setWriterAdminName(adminLogUserName1);
		//页面跳转
		request.getSession().setAttribute("adminFindOneLog", adminFindOneLog);
		request.getRequestDispatcher("/journal/adminUpdateSelfLog.jsp").forward(request,response);
		
	}

	//管理员查看自己的日志--列表
	private void adminLookSelfLogs(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int page = 0;
		String adminCode = request.getParameter("adminCode");
		System.out.println("aini" + adminCode);
		String currPage = request.getParameter("page");
		if(currPage == null) {
			page = 1;
		}else {
			page = Integer.parseInt(currPage);
		}
		LogService logService = new LogServiceImpl();
		PageBean<Log> adminLookSelfLogsPageBean = logService.adminFindLogByPage(page,adminCode);
		System.out.println(adminLookSelfLogsPageBean);
		request.setAttribute("adminLookSelfLogsPageBean", adminLookSelfLogsPageBean);
		request.getRequestDispatcher("/journal/adminLookSelfLog.jsp").forward(request, response);
		
	}

	//管理员写日志
	private void adminXieLog(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String adminName1 = request.getParameter("adminName1");
		String adminCode1 = request.getParameter("adminCode1");
		String projectNameShangwu1 = request.getParameter("projectNameShangwu1");
		String shangwuStatus1 = request.getParameter("shangwuStatus1");
		String shangwuJihua1 = request.getParameter("shangwuJihua1");
		String projectNameXiawu1 = request.getParameter("projectNameXiawu1");
		String xiawuStatus1 = request.getParameter("xiawuStatus1");
		String xiawuJihua1 = request.getParameter("xiawuJihua1");
		System.out.println(projectNameShangwu1);
		System.out.println(shangwuStatus1);
		System.out.println(shangwuJihua1);
		System.out.println(projectNameXiawu1);
		System.out.println(xiawuStatus1);
		System.out.println(xiawuJihua1);
		//封装数据
		Log userLog = new Log();
		userLog.setWriterAdminName(adminName1);
		userLog.setWriterAdminCode(adminCode1);
		userLog.setShangwuPname(projectNameShangwu1);
		userLog.setShangwuPlan(shangwuJihua1);
		userLog.setShangwuStatus(shangwuStatus1);
		userLog.setXiawuPname(projectNameXiawu1);
		userLog.setXiawuStatus(xiawuStatus1);
		userLog.setXiawuPlan(xiawuJihua1);
		//处理数据 
		UserService userService = new UserServiceImpl();
		userService.addAdminLog(userLog); 
		//页面跳转
		response.sendRedirect(request.getContextPath() + "/main.jsp");
		
	}


	//模糊查询--根据用户姓名或账号查询用户
	private void searchUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 接受数据
		System.out.println("test001");
		String likeUser = request.getParameter("condition");
		System.out.println(likeUser);
		UserService userService = new UserServiceImpl();
		List<User> likeList = userService.likeSearchUser(likeUser);
		request.setAttribute("likeList", likeList);
		request.getRequestDispatcher("/user/searchUser.jsp").forward(request, response);
		
	}

	//修改用户第二步：修改用户信息
	private void updateUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Integer emId = Integer.parseInt(request.getParameter("em_id"));
		String userName = request.getParameter("userName");
		String userPhone = request.getParameter("userPhone");
		String userCardId = request.getParameter("userCardId");
		String userCode = request.getParameter("userCode");
		User user = new User();
		user.setUserId(emId);
		user.setUserName(userName);
		user.setUserPhone(userPhone);
		user.setUserPid(userCardId);
		user.setUserCode(userCode);
		UserService userService = new UserServiceImpl();
		userService.updateUser(user);
		response.sendRedirect(request.getContextPath() + "/userPageServlet");
	}

	//修改用户第一步：回显数据
	private void huixianUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接收参数
		Integer emId = Integer.parseInt(request.getParameter("em_id"));
		//处理数据
		UserService userService = new UserServiceImpl();
		User hxUser = userService.hxUser(emId);
		request.setAttribute("hxUser", hxUser);
		request.getRequestDispatcher("/user/modifyUserList.jsp").forward(request, response);
	}

	//管理员删除用户
	private void deleteUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
		//接收参数
		Integer emId = Integer.parseInt(request.getParameter("em_id"));
		//处理数据
		GuanliService deleteUserService = new GuanliServiceImpl();
		deleteUserService.deleteUser(emId);
		//页面跳转
		response.sendRedirect(request.getContextPath() + "/userPageServlet");
	}
	//管理员退出登录
	private void adminLogout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		//将session销毁掉
		request.getSession().invalidate();
		//页面重定向
		response.sendRedirect(request.getContextPath() + "/mainpage.jsp");
	}

	

	//添加用户
	private void addUser(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		//接受页面数据
		String userName = request.getParameter("userName");
		String userPhone = request.getParameter("userPhone");
		String userCardId = request.getParameter("userCardId");
		String userCode = request.getParameter("userCode");
		String userPassword = request.getParameter("userPassword");
		String userPasswordAgain = request.getParameter("userPasswordAgain");
		if(userPassword.equals(userPasswordAgain)) {
			//封装数据
			User addUser = new User();
			addUser.setUserName(userName);
			addUser.setUserPhone(userPhone);
			addUser.setUserPid(userCardId);
			addUser.setUserCode(userCode);
			addUser.setUserPassword(userPassword);
			//处理数据
			GuanliService addUserService = new GuanliServiceImpl();
			addUserService.addUser(addUser);
			//页面跳转
			response.sendRedirect(request.getContextPath() + "/userPageServlet");
		}else {
			request.setAttribute("msg4", "两次密码输入不一致，请重新输入！");
			request.getRequestDispatcher("/user/addUserList.jsp").forward(request,response);
		}
		
	}
	
	//管理员填写新密码
	private void adminUpdatePassword(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		//接受前台写入的新密码和确认新密码
		String newPassword = request.getParameter("newPassword");
		String newPasswordAgain = request.getParameter("newPasswordAgain");
		if(newPassword.equals(newPasswordAgain)) {
			//封装数据
			Guanli guanliUpdatePassword = new Guanli();
			guanliUpdatePassword.setAdminPassword(newPassword);
			guanliUpdatePassword.setAdminCode(updatePasswordCode);
			System.out.println(guanliUpdatePassword.getAdminPassword()+" "+guanliUpdatePassword.getAdminCode());
			//处理数据
			GuanliService guanliUpdatePasswordService = new GuanliServiceImpl();
			guanliUpdatePasswordService.adminUpdatePassword(guanliUpdatePassword);
			//页面跳转
			response.sendRedirect(request.getContextPath() + "/mainpage.jsp");
		}else {
			request.setAttribute("msg2", "两次密码输入不一致，请重新输入！");
			request.getRequestDispatcher("/adminNewPassword.jsp").forward(request,response);
		}
	}

	//管理员忘记密码--需成功填写账户各项信息
	private void adminForgetPassword(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接收前台数据：账号--身份证--姓名--手机
		String adminCode = request.getParameter("adminCode");
		String adminPid = request.getParameter("adminCardId");
		String adminName = request.getParameter("adminName");
		String adminPhone = request.getParameter("adminPhone");
		updatePasswordCode = adminCode;
		System.out.println(adminCode+" "+adminPid+" "+adminName+" "+adminPhone);
		//封装数据
		Guanli guanliForget = new Guanli();
		guanliForget.setAdminCode(adminCode);
		guanliForget.setAdminName(adminName);
		guanliForget.setAdminPhoneNum(adminPhone);
		guanliForget.setAdminPid(adminPid);
		//处理数据
		GuanliService guanliForgetService = new GuanliServiceImpl();
		Guanli existGuanliForget = guanliForgetService.adminForgetPassword(guanliForget);
		if(existGuanliForget == null) {
			//管理员身份信息输入有误，返回找回密码页面
			request.setAttribute("msg1", "管理员身份信息填写错误！");
			request.getRequestDispatcher("/adminForgetPassword.jsp").forward(request,response);
		}else {
			//管理员身份信息填写正确--将管理员信息进行保存,然后进行页面跳转
			request.getSession().setAttribute("existGuanliForget", existGuanliForget);
			response.sendRedirect(request.getContextPath() + "/adminNewPassword.jsp");
		}
	}

	//管理员登录
	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接受用户名和密码
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		System.out.println(username + "  " + password);
		//数据的封装
		Guanli guanli = new Guanli();
		guanli.setAdminCode(username);
		guanli.setAdminPassword(password);
		//处理数据
		GuanliService guanliService = new GuanliServiceImpl();
		Guanli existGuanli = guanliService.login(guanli);
		if(existGuanli == null) {
			//登陆失败--返回登陆页面
			request.setAttribute("msg", "用户名或密码错误！");
			request.getRequestDispatcher("/adminlogin.jsp").forward(request,response);
		}else {
			//登录成功--将用户信息进行保存,然后进行页面跳转
			request.getSession().setAttribute("existGuanli", existGuanli);
			response.sendRedirect(request.getContextPath() + "/main.jsp");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
