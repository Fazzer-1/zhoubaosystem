package com.zj.web.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zj.domain.Log;
import com.zj.domain.PageBean;
import com.zj.service.LogService;
import com.zj.service.impl.LogServiceImpl;

@WebServlet("/userLogPageServlet")
public class userLogPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//用户查询自己的日志，分页查询--查询结果形式：列表
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int page = 0;
		String userCodePage = request.getParameter("userCodePage");
		System.out.println("aini" + userCodePage);
		String currPage = request.getParameter("page");
		if(currPage == null) {
			page = 1;
		}else {
			page = Integer.parseInt(currPage);
		}
		LogService logService = new LogServiceImpl();
		PageBean<Log> userLogPageBean = logService.findByPage(page,userCodePage);
		System.out.println(userLogPageBean);
		request.setAttribute("userLogPageBean", userLogPageBean);
		request.getRequestDispatcher("/journal/userLookLog.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
