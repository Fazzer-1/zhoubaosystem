package com.zj.web.action;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zj.domain.Guanli;
import com.zj.domain.Log;
import com.zj.domain.PageBean;
import com.zj.domain.Shijian;
import com.zj.domain.User;
import com.zj.service.GuanliService;
import com.zj.service.LogService;
import com.zj.service.UserService;
import com.zj.service.impl.GuanliServiceImpl;
import com.zj.service.impl.LogServiceImpl;
import com.zj.service.impl.UserServiceImpl;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String updatePasswordCode = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接收参数
		String methodName = request.getParameter("method");
		//判断
		if("userLogin".equals(methodName)) {
			userLogin(request,response);
		}else if("userLogout".equals(methodName)) {
			userLogout(request,response);
		}else if("userXieLog".equals(methodName)) {
			userXieLog(request,response);
		}else if("findOneLog".equals(methodName)) {
			try {
				findOneLog(request,response);
			} catch (ServletException | IOException | ParseException e) {
				e.printStackTrace();
			}
		}else if("userUpdateLog".equals(methodName)) {
			userUpdateLog(request,response);
		}else if("findLogByTime".equals(methodName)) {
			try {
				findLogByTime(request,response);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("userFindOneLogByTime".equals(methodName)) {
			try {
				userFindOneLogByTime(request,response);
			} catch (ParseException | ServletException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if("userUpdateLogByTime".equals(methodName)) {
			userUpdateLogByTime(request,response);
		}else if("userForgetPassword".equals(methodName)) {
			userForgetPassword(request,response);
		}else if("userUpdatePassword".equals(methodName)) {
			userUpdatePassword(request,response);
		}
	}
	
	//用户忘记密码---第二部：修改密码
	private void userUpdatePassword(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String newPassword = request.getParameter("newPassword");
		String newPasswordAgain = request.getParameter("newPasswordAgain");
		if(newPassword.equals(newPasswordAgain)) {
			//封装数据
			User userUpdatePassword = new User();
			userUpdatePassword.setUserPassword(newPassword);
			userUpdatePassword.setUserCode(updatePasswordCode);
			//处理数据
			UserService userUpdatePasswordService = new UserServiceImpl();
			userUpdatePasswordService.userUpdatePassword(userUpdatePassword);
			//页面跳转
			response.sendRedirect(request.getContextPath() + "/mainpage.jsp");
		}else {
			request.setAttribute("msg22", "两次用户密码输入不一致，请重新输入！");
			request.getRequestDispatcher("/userNewPassword.jsp").forward(request,response);
		}
		
	}

	//用户忘记密码---第一步：验证
	private void userForgetPassword(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userCode = request.getParameter("userCode");
		String userCardId = request.getParameter("userCardId");
		String userName = request.getParameter("userName");
		String userPhone = request.getParameter("userPhone");
		updatePasswordCode = userCode;
		//封装数据
		User userforget = new User();
		userforget.setUserCode(userCode);
		userforget.setUserPid(userCardId);
		userforget.setUserName(userName);
		userforget.setUserPhone(userPhone);
		//处理数据
		UserService userForgetService = new UserServiceImpl();
		User existUserForget = userForgetService.userForgetPassword(userforget);
		if(existUserForget == null) {
			//管理员身份信息输入有误，返回找回密码页面
			request.setAttribute("msg10", "用户身份信息填写错误！");
			request.getRequestDispatcher("/userForgetPassword.jsp").forward(request,response);
		}else {
			//管理员身份信息填写正确--将管理员信息进行保存,然后进行页面跳转
			request.getSession().setAttribute("existUserForget", existUserForget);
			response.sendRedirect(request.getContextPath() + "/userNewPassword.jsp");
		}
		
	}

	//用户根据时间查日志--查出一篇日志的细则--修改日志内容
	private void userUpdateLogByTime(HttpServletRequest request, HttpServletResponse response) throws IOException {
		//接收数据
		String projectNameShangwu2 = request.getParameter("projectNameShangwu2");
		String shangwuStatus2 = request.getParameter("shangwuStatus2");
		String shangwuPlan2 = request.getParameter("shangwuPlan2");
		String projectNameXiawu2 = request.getParameter("projectNameXiawu2");
		String xiawuStatus2 = request.getParameter("xiawuStatus2");
		String xiawuJihua2 = request.getParameter("xiawuJihua2");
		Integer logId2 = Integer.parseInt(request.getParameter("logId2"));
		//封装数据
		Log userUpLog = new Log();
		userUpLog.setShangwuPname(projectNameShangwu2);
		userUpLog.setShangwuPlan(shangwuPlan2);
		userUpLog.setShangwuStatus(shangwuStatus2);
		userUpLog.setXiawuPname(projectNameXiawu2);
		userUpLog.setXiawuPlan(xiawuJihua2);
		userUpLog.setXiawuStatus(xiawuStatus2);
		userUpLog.setLogId(logId2);
		//处理数据
		UserService userService = new UserServiceImpl();
		userService.updateUserLogByTime(userUpLog);
		//页面跳转
		response.sendRedirect(request.getContextPath() + "/mainUser.jsp");
		
	}

	//用户根据时间查日志--查出一篇日志的细则
	private void userFindOneLogByTime(HttpServletRequest request, HttpServletResponse response) throws ParseException, ServletException, IOException {
		DateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
		//接收数据
		Integer userLogId3 = Integer.parseInt(request.getParameter("userLogId3"));
		Timestamp userLogTime3 = new Timestamp(format.parse(request.getParameter("userLogTime3")).getTime());
		String userLogShangwuPname3 = request.getParameter("userLogShangwuPname3");
		String userLogShangwuPlan3 = request.getParameter("userLogShangwuPlan3");
		String userLogShangwuStatus3 = request.getParameter("userLogShangwuStatus3");
		String userLogXiawuPname3 = request.getParameter("userLogXiawuPname3");
		String userLogXiawuPlan3 = request.getParameter("userLogXiawuPlan3");
		String userLogXiawuStatus3 = request.getParameter("userLogXiawuStatus3");
		String userLogUserCode3 = request.getParameter("userLogUserCode3");
		String userLogUserName3 = request.getParameter("userLogUserName3");
		System.out.println(userLogTime3);
		//封装数据
		Log userTimeLog = new Log();
		userTimeLog.setLogId(userLogId3);
		userTimeLog.setTime(userLogTime3);
		userTimeLog.setShangwuPname(userLogShangwuPname3);
		userTimeLog.setShangwuPlan(userLogShangwuPlan3);
		userTimeLog.setShangwuStatus(userLogShangwuStatus3);
		userTimeLog.setXiawuPname(userLogXiawuPname3);
		userTimeLog.setXiawuPlan(userLogXiawuPlan3);
		userTimeLog.setXiawuStatus(userLogXiawuStatus3);
		userTimeLog.setWriterUserCode(userLogUserCode3);
		userTimeLog.setWriterUserName(userLogUserName3);
		//页面跳转
		request.getSession().setAttribute("userFindOneLogByTime", userTimeLog);
		request.getRequestDispatcher("/journal/userUpdateLogByTime.jsp").forward(request,response);
	}

	//用户根据时间查日志--查出所有日志，查询结果形式：列表
	private void findLogByTime(HttpServletRequest request, HttpServletResponse response) throws ParseException, ServletException, IOException {
		// 接受前台的时间，并且转换类型
		String startTime = request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		String timeUserCode = request.getParameter("timeUserCode");
		System.out.println("获取数据"+timeUserCode);
		//赋值
		Shijian shijian = new Shijian();
		shijian.setKaishiTime(startTime);
		shijian.setJieshuTime(endTime);
		request.getSession().setAttribute("shijian", shijian);
		//转换类型
		String a =startTime.substring(0, 4).concat(startTime.substring(5, 7));
		String b =a.concat(startTime.substring(8, 10));
		String c = "000000";
		String d = b.concat(c);
		DateFormat format1 = new SimpleDateFormat("yyyyMMddHHmmss");
		Timestamp startTime1 = new Timestamp(format1.parse(d).getTime());
		System.out.println(startTime1);
		String e =endTime.substring(0, 4).concat(endTime.substring(5, 7));
		String f =e.concat(endTime.substring(8, 10));
		String g = "000000";
		String q = f.concat(g);
		DateFormat format2 = new SimpleDateFormat("yyyyMMddHHmmss");
		Timestamp endTime1 = new Timestamp(format2.parse(q).getTime());
		System.out.println(endTime1);
		//处理数据
		int page = 0;
		String currPage = request.getParameter("page");
		if(currPage == null) {
			page = 1;
		}else {
			page = Integer.parseInt(currPage);
		}
		UserService userService = new UserServiceImpl();
		PageBean<Log> userLookLogByTimePageBean = userService.userFindLogByTime(page,startTime1,endTime1,timeUserCode);
		System.out.println(userLookLogByTimePageBean);
		request.setAttribute("userLookLogByTimePageBean", userLookLogByTimePageBean);
		request.getRequestDispatcher("/journal/userLookLogByTime.jsp").forward(request, response);
	}

	//用户修改日志
	private void userUpdateLog(HttpServletRequest request, HttpServletResponse response) throws IOException {
		//接收数据
		String projectNameShangwu2 = request.getParameter("projectNameShangwu2");
		String shangwuStatus2 = request.getParameter("shangwuStatus2");
		String shangwuPlan2 = request.getParameter("shangwuPlan2");
		String projectNameXiawu2 = request.getParameter("projectNameXiawu2");
		String xiawuStatus2 = request.getParameter("xiawuStatus2");
		String xiawuJihua2 = request.getParameter("xiawuJihua2");
		Integer logId2 = Integer.parseInt(request.getParameter("logId2"));
		//封装数据
		Log userUpLog = new Log();
		userUpLog.setShangwuPname(projectNameShangwu2);
		userUpLog.setShangwuPlan(shangwuPlan2);
		userUpLog.setShangwuStatus(shangwuStatus2);
		userUpLog.setXiawuPname(projectNameXiawu2);
		userUpLog.setXiawuPlan(xiawuJihua2);
		userUpLog.setXiawuStatus(xiawuStatus2);
		userUpLog.setLogId(logId2);
		//处理数据
		UserService userService = new UserServiceImpl();
		userService.updateUserLog(userUpLog);
		//页面跳转
		response.sendRedirect(request.getContextPath() + "/mainUser.jsp");
	}

	//查询单个用户的单个日志
	private void findOneLog(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ParseException {
		DateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
		//接收数据
		Integer userLogId1 = Integer.parseInt(request.getParameter("userLogId1"));
		Timestamp userLogTime1 = new Timestamp(format.parse(request.getParameter("userLogTime1")).getTime());
		String userLogShangwuPname1 = request.getParameter("userLogShangwuPname1");
		String userLogShangwuPlan1 = request.getParameter("userLogShangwuPlan1");
		String userLogShangwuStatus1 = request.getParameter("userLogShangwuStatus1");
		String userLogXiawuPname1 = request.getParameter("userLogXiawuPname1");
		String userLogXiawuPlan1 = request.getParameter("userLogXiawuPlan1");
		String userLogXiawuStatus1 = request.getParameter("userLogXiawuStatus1");
		String userLogUserCode1 = request.getParameter("userLogUserCode1");
		String userLogUserName1 = request.getParameter("userLogUserName1");
		System.out.println(userLogTime1);
		//封装数据	
		Log findOneLog = new Log();
		findOneLog.setLogId(userLogId1);
		findOneLog.setTime(userLogTime1);
		findOneLog.setShangwuPname(userLogShangwuPname1);
		findOneLog.setShangwuPlan(userLogShangwuPlan1);
		findOneLog.setShangwuStatus(userLogShangwuStatus1);
		findOneLog.setXiawuPname(userLogXiawuPname1);
		findOneLog.setXiawuPlan(userLogXiawuPlan1);
		findOneLog.setXiawuStatus(userLogXiawuStatus1);
		findOneLog.setWriterUserCode(userLogUserCode1);
		findOneLog.setWriterUserName(userLogUserName1);
		//页面跳转
		request.getSession().setAttribute("findOneLog", findOneLog);
		request.getRequestDispatcher("/journal/userUpdateLog.jsp").forward(request,response);
		
	}
	//用户写日志
	private void userXieLog(HttpServletRequest request, HttpServletResponse response) throws IOException {
		//接受页面数据
		String userName1 = request.getParameter("userName1");
		String userCode1 = request.getParameter("userCode1");
		String projectNameShangwu1 = request.getParameter("projectNameShangwu1");
		String shangwuStatus1 = request.getParameter("shangwuStatus1");
		String shangwuJihua1 = request.getParameter("shangwuJihua1");
		String projectNameXiawu1 = request.getParameter("projectNameXiawu1");
		String xiawuStatus1 = request.getParameter("xiawuStatus1");
		String xiawuJihua1 = request.getParameter("xiawuJihua1");
		System.out.println(userName1);
		System.out.println(userCode1);
		System.out.println(projectNameShangwu1);
		System.out.println(shangwuStatus1);
		System.out.println(shangwuJihua1);
		System.out.println(projectNameXiawu1);
		System.out.println(xiawuStatus1);
		System.out.println(xiawuJihua1);
		//封装数据
		Log userLog = new Log();
		userLog.setWriterUserName(userName1);
		userLog.setWriterUserCode(userCode1);
		userLog.setShangwuPname(projectNameShangwu1);
		userLog.setShangwuPlan(shangwuJihua1);
		userLog.setShangwuStatus(shangwuStatus1);
		userLog.setXiawuPname(projectNameXiawu1);
		userLog.setXiawuStatus(xiawuStatus1);
		userLog.setXiawuPlan(xiawuJihua1);
		//处理数据 
		UserService userService = new UserServiceImpl();
		userService.addUserLog(userLog); 
		//页面跳转
		response.sendRedirect(request.getContextPath() + "/mainUser.jsp");
	}

	//用户退出登录
	private void userLogout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		//将session销毁掉
		request.getSession().invalidate();
		//页面重定向s
		response.sendRedirect(request.getContextPath() + "/mainpage.jsp");
		
	}

	private void userLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接受用户名和密码
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		System.out.println(username + "  " + password);
		//数据的封装
		User user = new User();
		user.setUserCode(username);
		user.setUserPassword(password);
		//处理数据
		UserService userService = new UserServiceImpl();
		User existUser = userService.userLogin(user);
		if(existUser == null) {
			//登陆失败--返回登陆页面
			request.setAttribute("msg11", "用户名或密码错误！");
			request.getRequestDispatcher("/userlogin.jsp").forward(request,response);
		}else {
			//登录成功--将用户信息进行保存,然后进行页面跳转
			request.getSession().setAttribute("existUser", existUser);
			response.sendRedirect(request.getContextPath() + "/mainUser.jsp");
		}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
